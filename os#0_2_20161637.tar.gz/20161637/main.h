#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"
#include "bitmap.h"
#include "hash.h"

typedef struct _list{
    char name[10];
    struct list *point;
}list;

typedef struct _hash{
    char name[10];
    struct hash* point;
}hashtable;

typedef struct _bitmaptable{
    char name[10];
    struct bitmap* point;
}bitmaptable;

list list_array[10];
hashtable hash_array[10];
bitmaptable bitmap_array[10];

//to divide command into parameter
char input[100], input_copy[100];
char *command=NULL;
char *para1=NULL;
char *para2=NULL;
char *para3=NULL;
char *para4=NULL;
char *para5=NULL;
size_t list_cnt = 0, hash_cnt = 0, bitmap_cnt = 0;
/// /////////////////////////////////////////////// Functions used in main.c
void err_print(char* str); // print error
void dumpdata_list(char* name); // print list
void dumpdata_hash(char* name); // print hash
void dumpdata_bitmap(char* name); // print bitmap
int find_list_idx(char*); // find list index
int find_hash_idx(char*); // find hash index
int find_bitmap_idx(char*); // find bitmap index
//////////////////////////////////////////////////

// print error
void err_print (char* str){
    printf("%s, do it again\n",str);

    return ;
}

//find list index in list table
int find_list_idx(char* para) {
    int idx = 0;
    for (idx = 0; idx < 10; idx++) {
        if (strcmp(para, list_array[idx].name) == 0)
            break;
    }
    return idx;
}
// find hash index in hash table
int find_hash_idx(char* para) {
    int idx = 0;
    for (idx = 0; idx < 10; idx++) {
        if (strcmp(para, hash_array[idx].name) == 0)
            break;
    }
    return idx;
}
// find bitmap index in bitmap table
int find_bitmap_idx(char* para) {
    int idx = 0;
    for (idx = 0; idx < 10; idx++) {
        if (strcmp(para, bitmap_array[idx].name) == 0)
            break;
    }
    return idx;
}

// print list
void dumpdata_list(char* para) {
    struct list_elem* e;
    struct list_item* it;
    int idx = find_list_idx(para); 
    for (e = list_begin(list_array[idx].point) ; e != list_end(list_array[idx].point) ; e = list_next(e)) {
        it = list_entry(e, struct list_item, elem);
        printf("%d ", it->data);
    }
    printf("\n");
    return;
}
//print hash
void dumpdata_hash(char* para) {
    int idx = find_hash_idx(para);
    struct list_elem* list_elem;
    struct hash_item* item;
    struct hash_elem* hash_elem;    
    for (int i = 0; i < hash_array[idx].point->bucket_cnt; i++) 
    {
        for (list_elem = list_begin(&(hash_array[idx].point->buckets[i])) ; list_elem != list_end(&(hash_array[idx].point->buckets[i])) ; list_elem = list_next(list_elem)) 
        {
            hash_elem = list_entry(list_elem, struct hash_elem, list_elem);
            item = hash_entry(hash_elem, struct hash_item, elem);
            printf("%d ", item->data);
        }
    }
    printf("\n");
    return;
}
// print bitmap
void dumpdata_bitmap(char *para) {

    int idx = find_bitmap_idx(para);
    
    for (int i = 0; i < bitmap_array[idx].point->bit_cnt; i++) {
        if (bitmap_test(bitmap_array[idx].point, i) == true)
            printf("1");
        else
            printf("0");
    }
    printf("\n");
 }
