#include "main.h"

int main() {
    int list_idx = 0;
    int hash_idx = 0;
    int bitmap_idx = 0;
    int temp1 = 0;
    int temp2 = 0;
    int temp3 = 0;
    //initialize name
    for (int i = 0; i < 10; i++) {
        list_array[i].name[0] = '\0';
        hash_array[i].name[0] = '\0';
        bitmap_array[i].name[0] = '\0';
    }
    while (1) {
        fgets(input, sizeof(char) * 100, stdin);
        input[strlen(input) - 1] = '\0';
        strcpy(input_copy, input);
        command = strtok(input_copy, " ");
        para1 = strtok(NULL, " ");
        para2 = strtok(NULL, " ");
        para3 = strtok(NULL, " ");
        para4 = strtok(NULL, " ");
        para5 = strtok(NULL, " ");

        //create
        if (strcmp(command, "create") == 0) {
            if (para1 == NULL) {
                err_print("Create error");
            }
            //create list
            else if (strcmp(para1, "list") == 0) {
                list_array[list_cnt].point = (struct list*)malloc(sizeof(struct list));
                list_init(list_array[list_cnt].point);
                strcpy(list_array[list_cnt].name, para2);
                list_cnt++;
            }
            //create hashtable
            else if (strcmp(para1, "hashtable") == 0) {
                hash_array[hash_cnt].point = (struct hash*)malloc(sizeof(struct hash));
                hash_init(hash_array[hash_cnt].point,hash_hash_function,hash_less_function,NULL);
                strcpy(hash_array[hash_cnt].name, para2);
                hash_cnt++;
            }
            //create bitmap
            else if (strcmp(para1, "bitmap") == 0) { 
                size_t bit_size = 0;
                sscanf(para3, "%zu", &bit_size); //3��° �Ű��������� bit_size�� ����
                bitmap_array[bitmap_cnt].point = bitmap_create(bit_size); // bitmap_create ���ڷ� �ְ� bitmaptable���� �޽��ϴ�.
                strcpy(bitmap_array[bitmap_cnt].name, para2); //��Ʈ�� �̸��� �״�� �Ű��ݴϴ�.
                bitmap_cnt++;
            }
            else {
                err_print("Create error");
            }
        }
        //delete
        else if (strcmp(command, "delete") == 0) {
            if (para1 == NULL) {
                err_print("Cannot delete");
            }
            else {
                for (int i = 0; i < 10; i++) {
                    //delete list
                    if (strcmp(list_array[i].name, para1) == 0) {
                        for (int j = i; j < 9; j++) {
                            list_array[j] = list_array[j + 1];
                        }
                        break;
                    }
                    //delete bitmap
                    else if (strcmp(bitmap_array[i].name, para1) == 0) {
                        bitmap_destroy(bitmap_array[i].point);
                        break;
                    }
                }
            }
        }
        //dumpdata
        else if (strcmp(command, "dumpdata") == 0) {
            if (para1 == NULL) {
                err_print("Cannot dumpdata");
                continue;
            }
            for (int i = 0; i < 10; i++) {
                if (strcmp(list_array[i].name, para1) == 0) {
                    dumpdata_list(para1);
                    break;
                }
                else if (strcmp(hash_array[i].name, para1) == 0) {
                    dumpdata_hash(para1);
                    break;
                }
                else if (strcmp(bitmap_array[i].name, para1) == 0) {
                    dumpdata_bitmap(para1);
                    break;
                }
            }
        }
        else if (strcmp(command, "quit") == 0) {
            break;
        }
        ////////////////////////////////////////////listlistlist
        else if (strcmp(command, "list_push_back") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
            list_push_back(list_array[list_idx].point, &(item->elem));
            item = list_entry(&(item->elem), struct list_item, elem);
            item->data = temp1;
        }
        else if (strcmp(command, "list_push_front") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
            list_push_front(list_array[list_idx].point, &(item->elem));
            item = list_entry(&(item->elem), struct list_item, elem);
            item->data = temp1;

        }
        else if (strcmp(command, "list_insert") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item*));
            struct list_elem* before = list_begin(list_array[list_idx].point);
            if (&(list_array[list_idx].point->head) == list_array[list_idx].point->tail.prev) {
                before = &(item->elem);
                list_push_back(list_array[list_idx].point, before);
                list_array[list_idx].point->head.next = before;
                list_array[list_idx].point->tail.prev = before;
            }
            else {
                for (int i = 0; i < temp1; i++) {
                    before = before->next;
                }
                list_insert(before, &(item->elem));
            }
            item = list_entry(&(item->elem), struct list_item, elem);
            item->data = temp2;
        }
        else if (strcmp(command, "list_insert_ordered") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            struct list_item* item = (struct list_item*)malloc(sizeof(struct list_item));
            item = list_entry(&(item->elem), struct list_item, elem);
            item->data = temp1;
            list_insert_ordered(list_array[list_idx].point, &(item->elem), less, NULL);
        }
        else if (strcmp(command, "list_empty") == 0) {
            list_idx = find_list_idx(para1);
            bool result = list_empty(list_array[list_idx].point);
            if(result==true)
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "list_size") == 0) {
            list_idx = find_list_idx(para1);
            printf("%zu\n",list_size(list_array[list_idx].point));
        }
        else if (strcmp(command, "list_max") == 0) {
            list_idx = find_list_idx(para1);
             struct list_elem* elem = list_max(list_array[list_idx].point, less, NULL);
             struct list_item* item =list_entry(elem,struct list_item,elem);
             printf("%d\n",item->data);

            list_max(list_array[list_idx].point, less, NULL);
        }
        else if (strcmp(command, "list_min") == 0) {
            list_idx = find_list_idx(para1);
             struct list_elem* elem = list_min(list_array[list_idx].point, less, NULL);
             struct list_item* item =list_entry(elem,struct list_item,elem);
             printf("%d\n",item->data);

            list_min(list_array[list_idx].point, less, NULL);
        }
        else if (strcmp(command, "list_pop_back") == 0) {
            list_idx = find_list_idx(para1);
            list_pop_back(list_array[list_idx].point);
        }
        else if (strcmp(command, "list_pop_front") == 0) {
            list_idx = find_list_idx(para1);
            list_pop_front(list_array[list_idx].point);
        }
        else if (strcmp(command, "list_front") == 0) {
            list_idx = find_list_idx(para1);
            struct list_elem* elem = list_front(list_array[list_idx].point);
            struct list_item* item =list_entry(elem,struct list_item,elem);
            printf("%d\n",item->data);
        }
        else if (strcmp(command, "list_back") == 0) {
            list_idx = find_list_idx(para1);
             struct list_elem* elem = list_back(list_array[list_idx].point);
             struct list_item* item =list_entry(elem,struct list_item,elem);
             printf("%d\n",item->data);

        }
        else if (strcmp(command, "list_remove") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            struct list_elem* elem = list_begin(list_array[list_idx].point);
            for (int i = 0; i < temp1; i++) {
                elem = elem->next;
            }
            list_remove(elem);
        }
        else if (strcmp(command, "list_reverse") == 0) {
            list_idx = find_list_idx(para1);
            list_reverse(list_array[list_idx].point);
        }
        else if (strcmp(command, "list_shuffle") == 0) {
            list_idx = find_list_idx(para1);
            list_shuffle(list_array[list_idx].point);
        }
        else if (strcmp(command, "list_sort") == 0) {
            list_idx = find_list_idx(para1);
            list_sort(list_array[list_idx].point, less, NULL);
        }
        else if (strcmp(command, "list_splice") == 0) {
            list_idx = find_list_idx(para1);
            int list_idx2 = find_list_idx(para3);
            sscanf(para2, "%d", &temp1);
            sscanf(para4, "%d", &temp2);
            sscanf(para5, "%d", &temp3);
            struct list_elem* before = list_begin(list_array[list_idx].point);
            struct list_elem* first = list_begin(list_array[list_idx2].point);
            struct list_elem* last = list_begin(list_array[list_idx2].point);
            for (int i = 0; i < temp1; i++) {
                before = before->next;
            }
            for (int i = 0; i < temp2; i++) {
                first = first->next;
            }
            for (int i = 0; i < temp3; i++) {
                last = last->next;
            }
            list_splice(before, first, last);
        }
        else if (strcmp(command, "list_swap") == 0) {
            list_idx = find_list_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            struct list_elem* elem1 = list_begin(list_array[list_idx].point);
            struct list_elem* elem2 = list_begin(list_array[list_idx].point);
            for (int i = 0; i < temp1; i++) {
                elem1 = elem1->next;
            }
            for (int i = 0; i < temp2; i++) {
                elem2 = elem2->next;
            }

            list_swap(elem1, elem2);
        }
        else if (strcmp(command, "list_unique") == 0) {
            list_idx = find_list_idx(para1);

            if (para2 != NULL) {
                int list_idx_2 = find_list_idx(para2);
                list_unique(list_array[list_idx].point, list_array[list_idx_2].point, less, NULL);
            }
            else
                list_unique(list_array[list_idx].point, NULL, less, NULL);
        }
        ////////////////////////////////////////////HashHashHash!
        else if (strcmp(command, "hash_insert") == 0) {
            struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
            hash_idx = find_hash_idx(para1);
            sscanf(para2, "%d", &temp1);
            item->data = temp1;
            hash_insert(hash_array[hash_idx].point, &(item->elem));
}
        else if (strcmp(command, "hash_apply") == 0) {
            hash_idx = find_hash_idx(para1);
            if(strcmp(para2,"square")==0)
                hash_apply(hash_array[hash_idx].point, hash_square);
            else if (strcmp(para2, "triple") == 0) {
                hash_apply(hash_array[hash_idx].point, hash_triple);
            }
        }
        else if (strcmp(command, "hash_delete") == 0) {
            struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
            hash_idx = find_hash_idx(para1);
            sscanf(para2, "%d",&temp1);
            item->data = temp1;

            hash_delete(hash_array[hash_idx].point, &(item->elem));
        }
        else if (strcmp(command, "hash_empty") == 0) {
            hash_idx = find_hash_idx(para1);
            if (hash_empty(hash_array[hash_idx].point) == true)
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "hash_size") == 0) {
            hash_idx = find_hash_idx(para1);
            printf("%zu\n",hash_size(hash_array[hash_idx].point)); 
        }
        else if (strcmp(command, "hash_clear") == 0) {
            hash_idx = find_hash_idx(para1);
            hash_clear(hash_array[hash_idx].point, hash_destructor);
        }
        else if (strcmp(command, "hash_find") == 0) {
            hash_idx = find_hash_idx(para1);
            struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
            sscanf(para2, "%d", &temp1);
            item->data = temp1;

            if (hash_find(hash_array[hash_idx].point, &(item->elem)) != NULL)
                printf("%d\n", item->data);
        }
        else if (strcmp(command, "hash_replace") == 0) {
            hash_idx = find_hash_idx(para1);
            struct hash_item* item = (struct hash_item*)malloc(sizeof(struct hash_item));
            sscanf(para2, "%d", &temp1);
            item->data = temp1;
            hash_replace(hash_array[hash_idx].point, &(item->elem));
        }
        ///////////////////////////////////////////BitmapBitmapBitmap
        else if (strcmp(command, "bitmap_mark") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            bitmap_mark(bitmap_array[bitmap_idx].point, temp1);
        }
        else if (strcmp(command, "bitmap_all") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            if (bitmap_all(bitmap_array[bitmap_idx].point, temp1, temp2) == true)
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "bitmap_any") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            
            if(bitmap_any(bitmap_array[bitmap_idx].point, temp1, temp2) == true)
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "bitmap_contains") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            bool result = 0;
            if (strcmp(para4, "true") == 0) {
                result = bitmap_contains(bitmap_array[bitmap_idx].point, temp1, temp2, true);
            }
            else {
                result = bitmap_contains(bitmap_array[bitmap_idx].point, temp1, temp2, false);
            }
            if(result == true) 
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "bitmap_count") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            size_t result = 0;
            if (strcmp(para4, "true") == 0) {
                result = bitmap_count(bitmap_array[bitmap_idx].point, temp1, temp2, true);
            }
            else {
                result = bitmap_count(bitmap_array[bitmap_idx].point, temp1, temp2, false);
            }
            printf("%zu\n",result);
        }
        else if (strcmp(command, "bitmap_dump") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            bitmap_dump(bitmap_array[bitmap_idx].point);
        }
        else if (strcmp(command, "bitmap_expand") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d",&temp1);
            bitmap_array[bitmap_idx].point = bitmap_expand(bitmap_array[bitmap_idx].point,temp1);
        }
        else if (strcmp(command, "bitmap_flip") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2,"%d",&temp1);
            bitmap_flip(bitmap_array[bitmap_idx].point,temp1);
        }
        else if (strcmp(command, "bitmap_none") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            bool result = bitmap_none(bitmap_array[bitmap_idx].point, temp1,temp2);
            if(result == true)
                printf("true\n");
            else
                printf("false\n");
        }
        else if (strcmp(command, "bitmap_reset") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            bitmap_reset(bitmap_array[bitmap_idx].point, temp1);
        }
        else if (strcmp(command, "bitmap_scan") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            size_t result = 0;
            if (strcmp(para4, "true") == 0) {
                result = bitmap_scan(bitmap_array[bitmap_idx].point, temp1, temp2, true);
            }
            else {
                result = bitmap_scan(bitmap_array[bitmap_idx].point, temp1, temp2, false);
            }
            printf("%zu\n", result);
        }
        else if (strcmp(command, "bitmap_scan_and_flip") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            size_t result = 0;
            if (strcmp(para4, "true") == 0) {
                result = bitmap_scan_and_flip(bitmap_array[bitmap_idx].point, temp1, temp2, true);
            }
            else {
                result = bitmap_scan_and_flip(bitmap_array[bitmap_idx].point, temp1, temp2, false);
            }
            printf("%zu\n", result);
        }
        else if (strcmp(command, "bitmap_set") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);

            if (strcmp(para3, "true") == 0) {
                bitmap_set(bitmap_array[bitmap_idx].point, temp1, true);
            }
            else if (strcmp(para3, "false") == 0) {
                bitmap_set(bitmap_array[bitmap_idx].point, temp1, false);
            }
        }
        else if (strcmp(command, "bitmap_set_all") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            if (strcmp(para2, "true") == 0) {
                bitmap_set_all(bitmap_array[bitmap_idx].point, true);
            }
            else {
                bitmap_set_all(bitmap_array[bitmap_idx].point, false);
            }
        }
        else if (strcmp(command, "bitmap_set_multiple") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            sscanf(para3, "%d", &temp2);
            if (strcmp(para4, "true") == 0) {
                bitmap_set_multiple(bitmap_array[bitmap_idx].point, temp1, temp2, true);
            }
            else {
                bitmap_set_multiple(bitmap_array[bitmap_idx].point, temp1, temp2, false);
            }
 
        }
        else if (strcmp(command, "bitmap_size") == 0) {
            size_t bit_size = 0;
            bitmap_idx = find_bitmap_idx(para1);
            bit_size = bitmap_size(bitmap_array[bitmap_idx].point);
            printf("%zu\n",bit_size);
        }
        else if (strcmp(command, "bitmap_test") == 0) {
            bitmap_idx = find_bitmap_idx(para1);
            sscanf(para2, "%d", &temp1);
            if(bitmap_test(bitmap_array[bitmap_idx].point,temp1)==true){
                printf("true\n");
            }
            else
                printf("false\n");
        }
        else {
            err_print("Not provided command");
        }
    }
    return 0;
}
