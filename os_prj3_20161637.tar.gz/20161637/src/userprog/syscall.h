#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H
#include "lib/user/syscall.h"
#include "filesys/off_t.h"
void syscall_init (void);

void halt (void);
void exit (int status);
pid_t exec (const char *cmd_line);
int wait (pid_t pid);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);


//additional part
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);

void check_vaddr(const void *vaddr);

struct file
{
    struct inode *inode;        
    off_t pos;                  
	bool deny_write;        
};


#endif /* userprog/syscall.h */
