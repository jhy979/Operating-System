#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include <string.h>
#include "threads/synch.h"
static void syscall_handler (struct intr_frame *);

struct lock file_lock;

void
syscall_init (void) 
{
 lock_init(&file_lock);
	intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
	int n, a,b,c,d;
  switch (*(uint32_t *)(f->esp)) {
    case SYS_HALT:
		halt();
		break;
    case SYS_EXIT:
	  check_vaddr(f->esp + 4);
	  exit(*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
	  check_vaddr(f->esp + 4);
	  f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_vaddr(f->esp + 4);
	  f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
	  break;
    case SYS_READ:
	  check_vaddr(f->esp + 20);
      check_vaddr(f->esp + 24);
      check_vaddr(f->esp + 28);
      f->eax = read((int)*(uint32_t *)(f->esp + 20), (void *)*(uint32_t *)(f->esp + 24), (unsigned)*((uint32_t *)(f->esp + 28)));
      break;
    case SYS_WRITE:
	check_vaddr(f->esp + 20);
	check_vaddr(f->esp + 24);
	check_vaddr(f->esp + 28);
	  f->eax = write((int)*(uint32_t *)(f->esp + 20), (void *)*(uint32_t *)(f->esp + 24), (unsigned)*((uint32_t *)(f->esp + 28)));
      break;
	case SYS_FIBO:
		check_vaddr(f->esp + 20);
		n = *(int*)(f->esp+20);
		f->eax = fibonacci(n);
	  break;
	case SYS_MAX4:
		check_vaddr(f->esp + 20);
		check_vaddr(f->esp + 24);
		check_vaddr(f->esp + 28);
		check_vaddr(f->esp + 32);
		a = *(int*)(f->esp + 20);
		b = *(int*)(f->esp + 24);
		c = *(int*)(f->esp + 28);
		d = *(int*)(f->esp + 32);
		f->eax = max_of_four_int(a,b,c,d);
	  break;
	case SYS_CREATE:
      check_vaddr(f->esp + 16);
      check_vaddr(f->esp + 20);
      f->eax = create((const char *)*(uint32_t *)(f->esp + 16), (unsigned)*(uint32_t *)(f->esp + 20));
      break;
	case SYS_REMOVE:
      check_vaddr(f->esp + 4);
      f->eax = remove((const char*)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_OPEN:
      check_vaddr(f->esp + 4);
      f->eax = open((const char*)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_FILESIZE:
      check_vaddr(f->esp + 4);
      f->eax = filesize((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_SEEK:
      check_vaddr(f->esp + 16);
      check_vaddr(f->esp + 20);
      seek((int)*(uint32_t *)(f->esp + 16), (unsigned)*(uint32_t *)(f->esp + 20));
      break;
    case SYS_TELL:
      check_vaddr(f->esp + 4);
      f->eax = tell((int)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_CLOSE:
      check_vaddr(f->esp + 4);
      close((int)*(uint32_t *)(f->esp + 4));
      break;
  }
 // thread_exit ();
}

void halt (void){
	 shutdown_power_off();
}
void exit (int status){
	printf("%s: exit(%d)\n", thread_name(), status);
    
	//나갈 때 상태 갱신
	thread_current() -> exit_status = status;
    thread_exit ();
	
	//프로세스 죽으면 file들을 close 직접해주자
	for (int i = 3; i < 128; i++) {
		if (thread_current()->fd[i] != NULL) {
			close(i);
		}
	}
}
pid_t exec (const char *cmd_line){
	 return process_execute(cmd_line);
}
int wait (pid_t pid){
	return process_wait(pid);
}
int read (int fd, void *buffer, unsigned size){
	unsigned result =0;
	unsigned int idx=0;
	check_vaddr(buffer);
	lock_acquire(&file_lock);
	//fd가 0일때는 read 1일때는 write
	if (fd == 0) {
		for (idx = 0; idx < size; idx++) {
			if (((char *)buffer)[idx] == '\0') {
				break;
			}
		}
		result = idx;
	}
	else if (fd > 2) { //fd가 3부터는 file_read
		if (thread_current()->fd[fd] == NULL)
			exit(-1);
		result = file_read(thread_current()->fd[fd], buffer, size);
	}
	lock_release(&file_lock);
	return (int)result;
}
int write (int fd, const void *buffer, unsigned size){
	int result = -1;
	check_vaddr(buffer);
	lock_acquire(&file_lock);
	//fd가 1일때는 쓰기, 0일때는 읽기
	if (fd == 1){
		putbuf(buffer, size);
		result = size;
	}
	else if (fd > 2){ //fd가 3부터는 file_write
		if (thread_current()->fd[fd] == NULL){
			lock_release(&file_lock);
			exit(-1);
		}
		if (thread_current()->fd[fd]->deny_write!=0)
			file_deny_write(thread_current()->fd[fd]);
		
		result = file_write(thread_current()->fd[fd], buffer, size);
	}
	lock_release(&file_lock);
	//둘다 포함 안될 경우 -1반환
	return result; 
}

//파일 생성
bool create (const char *file, unsigned size) {
	if(file == NULL)
		exit(-1);
	check_vaddr(file);
	return filesys_create(file, size);
}

//파일 제거
bool remove (const char *file) {
	if(file == NULL)
        exit(-1);
	check_vaddr(file);
	return filesys_remove(file);
}
//파일 열기
int open (const char *file) {
  struct file* fp=NULL;
   if(file == NULL)
        exit(-1);
   check_vaddr(file);
   fp = filesys_open(file);
   if (fp == NULL) {
	   return -1;
   }
   else {
	   for (int i = 3; i < 128; i++) {
		   if (thread_current()->fd[i] == NULL) {
			   //thread name하고 파이랗고 비교해서 일치할 경우 write하지마!
			   if (strcmp(thread_current()->name, file) == 0) {
				   file_deny_write(fp);
			   }
			   thread_current()->fd[i] = fp;
			   return i;
      }
    }
  }
   // 실패시 -1반환
   return -1;
}

//파일 사이즈 알려주기
int filesize (int index) {
	if (thread_current()->fd[index] == NULL)
		exit(-1);
	return file_length(thread_current()->fd[index]);
}

//파일찾기
void seek (int index, unsigned pos) {
	if (thread_current()->fd[index] == NULL)
		exit(-1);
	file_seek(thread_current()->fd[index], pos);
}

//Tell
unsigned tell (int index) {
	if (thread_current()->fd[index] == NULL)
		exit(-1);
	return file_tell(thread_current()->fd[index]);
}

//파일 close
void close (int index) {
	if (thread_current()->fd[index] == NULL)
		exit(-1);
	struct file *fp = thread_current()->fd[index];
	thread_current()->fd[index] = NULL;
	return file_close(fp);
}

//피보나치
int fibonacci(int n){
	int fn2=2, fn1 = 1, fn0 =1;
	if(n==1)
		return fn0;
	else if(n==2)
		return fn1;
	for(int i = 0 ; i <n-2;i++){
		fn2 = fn1+fn0;
		fn0 = fn1;
		fn1 = fn2;
	}
	return fn2;
}

int max_of_four_int(int a, int b, int c , int d){
	int max =a;
	if(max<b)
		max = b;
	if(max<c)
		max = c;
	if(max<d)
		max = d;
	return max;
}
//잘못된 address 거르기
void check_vaddr(const void *vaddr) {
  if (!is_user_vaddr(vaddr)) {
    exit(-1);
  }
}


