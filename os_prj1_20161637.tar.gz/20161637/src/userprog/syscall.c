#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
	int n, a,b,c,d;
  switch (*(uint32_t *)(f->esp)) {
    case SYS_HALT:
		halt();
		break;
    case SYS_EXIT:
	  check_vaddr(f->esp + 4);
	  exit(*(uint32_t *)(f->esp + 4));
      break;
    case SYS_EXEC:
	  check_vaddr(f->esp + 4);
	  f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
      break;
    case SYS_WAIT:
      check_vaddr(f->esp + 4);
	  f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
	  break;
    case SYS_READ:
	  check_vaddr(f->esp + 20);
      check_vaddr(f->esp + 24);
      check_vaddr(f->esp + 28);
      f->eax = read((int)*(uint32_t *)(f->esp + 20), (void *)*(uint32_t *)(f->esp + 24), (unsigned)*((uint32_t *)(f->esp + 28)));
      break;
    case SYS_WRITE:
	check_vaddr(f->esp + 20);
	check_vaddr(f->esp + 24);
	check_vaddr(f->esp + 28);
	  f->eax = write((int)*(uint32_t *)(f->esp + 20), (void *)*(uint32_t *)(f->esp + 24), (unsigned)*((uint32_t *)(f->esp + 28)));
      break;
	case SYS_FIBO:
		check_vaddr(f->esp + 20);
		n = *(int*)(f->esp+20);
		f->eax = fibonacci(n);
	  break;
	case SYS_MAX4:
		check_vaddr(f->esp + 20);
		check_vaddr(f->esp + 24);
		check_vaddr(f->esp + 28);
		check_vaddr(f->esp + 32);
		a = *(int*)(f->esp+20);
		b = *(int*)(f->esp+24);
		c = *(int*)(f->esp+28);
		d = *(int*)(f->esp+32);
		f->eax = max_of_four_int(a,b,c,d);
	  break;
  }
 // thread_exit ();
}

void halt (void){
	 shutdown_power_off();
}
void exit (int status){
	printf("%s: exit(%d)\n", thread_name(), status);
	//나갈 때 상태 갱신
	thread_current() -> exit_status = status;
	thread_exit ();
}
pid_t exec (const char *cmd_line){
	 return process_execute(cmd_line);
}
int wait (pid_t pid){
	return process_wait(pid);
}
int read (int fd, void *buffer, unsigned size){
	unsigned int idx=0;
	//fd가 0일때는 read 1일때는 write
  if (fd == 0) {
    for (idx = 0; idx < size; idx++) {
      if (((char *)buffer)[idx] == '\0') {
        return (int)idx;
      }
    }
  }
  return 0;
}
int write (int fd, const void *buffer, unsigned size){
	//fd가 1일때는 쓰기, 0일때는 읽기
	if (fd == 1) {
		putbuf(buffer, size);
		return size;
  }
  return -1; 
}

int fibonacci(int n){
	int fn2=2, fn1 = 1, fn0 =1;
	if(n==1)
		return fn0;
	else if(n==2)
		return fn1;
	for(int i = 0 ; i <n-2;i++){
		fn2 = fn1+fn0;
		fn0 = fn1;
		fn1 = fn2;
	}
	return fn2;
}

int max_of_four_int(int a, int b, int c , int d){
	int max =a;
	if(max<b)
		max = b;
	if(max<c)
		max = c;
	if(max<d)
		max = d;
	return max;
}
//잘못된 address 거르기
void check_vaddr(const void *vaddr) {
  if (!is_user_vaddr(vaddr)) {
    exit(-1);
  }
}

